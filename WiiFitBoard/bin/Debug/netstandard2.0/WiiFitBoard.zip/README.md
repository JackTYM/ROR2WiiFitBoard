# Wii Fit Board
Adds a wii fit board that gives you movement speed

# 1.0.0
Original Release

# 1.0.1
Added github link to manifest.json