# Wii Fit Board
Adds a wii fit board that gives you movement speed

# 1.0.0
Original Release

# 1.0.1
Added github link to manifest.json

# 1.1.0
Changed the movement speed buff to 40% rather than 20%

# 1.2.0
Balance Update Part 2: Made item legendary and changed movement speed buff to 200%