# Wii Fit Board
Adds a wii fit board that gives you movement speed

# 1.0.0
Original Release